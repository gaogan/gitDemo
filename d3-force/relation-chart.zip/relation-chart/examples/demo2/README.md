

# d3.js 力导向图绘制人物关系图谱

预览：https://xiedajian.github.io/D3-force-relation-demo/dist/index.html

![预览](https://github.com/xiedajian/D3-force-relation-demo/blob/master/src/img/relation.gif)

用到jquery + d3.js 
## 运行之前请先安装依赖

npm install

## 开发预览运行

npm run server


## 打包

npm run build






