//postcss 配置文件
module.exports = {
    plugins: [
        require('autoprefixer')   //最常用的postcss插件，自动补全css浏览器前缀
    ]
}